from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain_core.runnables import RunnableSequence
from langchain_core.output_parsers import StrOutputParser

# Load modern OpenAI model
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7)

# Prompt Template
prompt = PromptTemplate(
    input_variables=["topic"],
    template="Suggest a catchy blog title about {topic}."
)

# Parser
parser = StrOutputParser()

# Sequential chain (replaces old LLMChain)
chain = RunnableSequence(
    prompt | llm | parser
)

# Run the chain
topic = input("Enter a topic: ")
result = chain.invoke({"topic": topic})

print("Generated Blog Title:", result)
