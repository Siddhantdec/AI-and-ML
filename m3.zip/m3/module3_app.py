# ─────────────────────────────────────────────────────────────────────────────
# Module 3: Language Models for Agentic AI
# A simple Streamlit app demonstrating:
#   - HuggingFace Transformers (GPT-2 local)
#   - LLaMA 3 via Groq API (open-source LLM)
#   - LangChain for autonomous AI applications
#
# Setup:
#   1. pip install -r requirements.txt
#   2. Create .env file:  GROQ_API_KEY=gsk_your-key-here
#   3. python -m streamlit run module3_app.py
# ─────────────────────────────────────────────────────────────────────────────

import os
import streamlit as st
from dotenv import load_dotenv

# Load GROQ_API_KEY from .env file automatically
load_dotenv()

# LangChain imports
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

# HuggingFace (runs locally, no API key needed)
try:
    from transformers import pipeline
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Get Groq LLM
# Here we are actually defining our LLM (which will be used in both the chat and agent sections). 
# This function reads the API key from the environment and creates a ChatGroq instance with the specified model and temperature.
# ─────────────────────────────────────────────────────────────────────────────

def get_llm(model_name: str, temperature: float = 0.7):
    """Create a ChatGroq LLM instance using API key from .env"""
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        st.error("GROQ_API_KEY not found! Create a .env file with: GROQ_API_KEY=gsk_...")
        st.stop()
    return ChatGroq(api_key=api_key, model_name=model_name,
                    temperature=temperature, max_tokens=1024)


# ─────────────────────────────────────────────────────────────────────────────
# FEATURE 1: Chat with LLaMA / Gemma (Groq API)
# Demonstrates: LangChain + open-source LLM + multi-turn conversation
# ─────────────────────────────────────────────────────────────────────────────

def chat_with_llm(user_message: str, model_name: str, chat_history: list) -> str:
    """
    Send a message to an open-source LLM via Groq.
    Uses LangChain ChatPromptTemplate to structure the conversation.
    """
    llm = get_llm(model_name)       #we have already defined the llm function above 

    # Build the prompt: system instruction + conversation history + user input
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful AI assistant expert in language models and AI. "
                   "Answer clearly and concisely."),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{input}"),
    ])

    # LCEL chain: prompt -> LLM -> string output  (Langchain Expression Languages)
    chain = prompt | llm | StrOutputParser()     #this chains needs to follow a sequence

    # Get or create conversation history stored in Streamlit session state
    def get_history(session_id: str) -> ChatMessageHistory:
        if "chat_history_store" not in st.session_state:
            st.session_state["chat_history_store"] = ChatMessageHistory()
        return st.session_state["chat_history_store"]

    # Wrap chain with message history (enables multi-turn memory)
    chain_with_memory = RunnableWithMessageHistory(
        chain,
        get_history,
        input_messages_key="input",
        history_messages_key="history",
    )

    response = chain_with_memory.invoke(
        {"input": user_message},
        config={"configurable": {"session_id": "main"}},
    )
    return response


# ─────────────────────────────────────────────────────────────────────────────
# FEATURE 2: Simple Autonomous Agent (LangChain + Tools)
# Demonstrates: LLM using tools to complete a task autonomously
# ─────────────────────────────────────────────────────────────────────────────

from langchain_core.tools import tool

@tool
def calculator(expression: str) -> str:
    """Evaluates a math expression. Example: '25 * 4 + 10'"""
    try:
        result = eval(expression)   # noqa: S307
        return f"Result: {result}"
    except Exception as e:
        return f"Error: {e}"

@tool
def word_counter(text: str) -> str:
    """Counts the number of words in a given text."""
    count = len(text.split())
    return f"Word count: {count} words"

@tool
def text_summary(text: str) -> str:
    """Returns a short summary hint about the text (length, first words)."""
    words = text.split()
    preview = " ".join(words[:8]) + ("..." if len(words) > 8 else "")
    return f"Text has {len(words)} words. Starts with: '{preview}'"


def run_agent(user_task: str, model_name: str) -> str:
    """
    Autonomous agent that decides which tool to use based on the task.
    The LLM reasons about the task and calls the right tool.
    """
    from langchain_core.messages import ToolMessage

    tools = [calculator, word_counter, text_summary]
    llm   = get_llm(model_name, temperature=0.1)
    llm_with_tools = llm.bind_tools(tools)
    tool_map = {t.name: t for t in tools}

    messages = [
        SystemMessage(content="You are an autonomous AI agent. Use your tools to complete tasks accurately."),
        HumanMessage(content=user_task),
    ]

    # Agent loop: LLM thinks -> calls tool -> gets result -> answers
    for _ in range(3):
        response = llm_with_tools.invoke(messages)
        if not response.tool_calls:
            return response.content  # No tool needed — final answer

        messages.append(response)
        for tool_call in response.tool_calls:
            tool_fn = tool_map.get(tool_call["name"])
            args    = tool_call["args"]
            arg_val = list(args.values())[0] if len(args) == 1 else str(args)
            result  = tool_fn.invoke(arg_val) if tool_fn else "Tool not found"
            messages.append(ToolMessage(content=str(result), tool_call_id=tool_call["id"]))

    return llm_with_tools.invoke(messages).content


# ─────────────────────────────────────────────────────────────────────────────
# FEATURE 3: Local HuggingFace GPT-2 (no API key, runs on CPU)
# Demonstrates: HuggingFace Transformers library for text generation
# ─────────────────────────────────────────────────────────────────────────────

@st.cache_resource(show_spinner="Loading GPT-2 model locally...")
def load_gpt2():
    """Load GPT-2 from HuggingFace — runs on your CPU, no API key needed."""
    if not HF_AVAILABLE:
        return None
    return pipeline("text-generation", model="gpt2", max_new_tokens=100,
                    do_sample=True, pad_token_id=50256)


def generate_with_gpt2(prompt: str) -> str:
    """Generate text using local GPT-2 transformer."""
    gen = load_gpt2()
    if gen is None:
        return "transformers not installed. Run: pip install transformers torch"
    output = gen(prompt, num_return_sequences=1, temperature=0.8)
    return output[0]["generated_text"]


# ─────────────────────────────────────────────────────────────────────────────
# STREAMLIT UI : for the frontend UI, we have a simple Streamlit app with three sections:
# 1. Chat with LLaMA/Gemma (Groq API)
# 2. Autonomous Agent using tools (LangChain)   
# ─────────────────────────────────────────────────────────────────────────────

def main():
    st.set_page_config(
        page_title="Module 3 — Language Models for Agentic AI",
        page_icon="🧠",
        layout="wide",
    )

    # Header
    st.title("🧠 Module 3: Language Models for Agentic AI")
    st.caption("HuggingFace Transformers · LLaMA 3 · LangChain · Groq API · python-dotenv")
    st.divider()

    # Sidebar: model selection and info
    with st.sidebar:
        st.header("⚙️ Settings")

        model = st.selectbox("Choose LLM (via Groq)", [
            "llama-3.1-8b-instant",     # LLaMA 3.1 — Meta AI (fast)
            "llama-3.3-70b-versatile",  # LLaMA 3.3 — Meta AI (powerful)
            "gemma2-9b-it",             # Gemma 2   — Google
            "mixtral-8x7b-32768",       # Mixtral   — Mistral AI
        ])

        st.divider()
        st.markdown("**About the models:**")
        st.markdown("""
        - **LLaMA 3** — Meta's open-source LLM, runs via Groq
        - **Gemma 2** — Google's open LLM, instruction-tuned
        - **Mixtral** — Mistral's Mixture-of-Experts model
        - **GPT-2** — OpenAI's original transformer (local)
        - **BLOOM** — BigScience multilingual LLM concept
        - **Falcon** — TII's open-source foundation model
        """)

        st.divider()
        st.markdown("**LangChain components used:**")
        st.markdown("""
        - `ChatGroq` — LLM wrapper
        - `ChatPromptTemplate` — prompt builder
        - `StrOutputParser` — output cleaner
        - `RunnableWithMessageHistory` — memory
        - `bind_tools` — agent tool use
        """)

        # Show API key status
        if os.environ.get("GROQ_API_KEY"):
            st.success("✅ GROQ_API_KEY loaded from .env")
        else:
            st.error("⚠️ GROQ_API_KEY not found!\nCreate .env: GROQ_API_KEY=gsk_...")

    # Three sections
    section = st.radio(
        "Choose a demo:",
        ["💬 Chat with LLM", "🤖 Autonomous Agent", "🤗 Local GPT-2 (HuggingFace)"],
        horizontal=True,
    )
    st.divider()

    # ── Section 1: Chat ────────────────────────────────────────────────────────
    if section == "💬 Chat with LLM":
        st.subheader("💬 Chat with Open-Source LLM")
        st.caption(f"Using **{model}** via Groq API · LangChain handles memory automatically")

        # Init chat display
        if "messages" not in st.session_state:
            st.session_state["messages"] = []

        # Show conversation
        for msg in st.session_state["messages"]:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])

        # User input
        user_input = st.chat_input("Ask anything about AI, language models, or any topic...")
        if user_input:
            with st.chat_message("user"):
                st.markdown(user_input)
            st.session_state["messages"].append({"role": "user", "content": user_input})

            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    reply = chat_with_llm(user_input, model, [])
                st.markdown(reply)
            st.session_state["messages"].append({"role": "assistant", "content": reply})

        if st.button("🗑️ Clear chat"):
            st.session_state["messages"] = []
            if "chat_history_store" in st.session_state:
                del st.session_state["chat_history_store"]
            st.rerun()

    # ── Section 2: Autonomous Agent ───────────────────────────────────────────
    elif section == "🤖 Autonomous Agent":
        st.subheader("🤖 Autonomous Agent with Tools")
        st.caption("The LLM decides which tool to call based on your task — no hardcoding")

        st.markdown("**Available tools the agent can use:**")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.info("🧮 **Calculator**\nSolves math expressions\n`25 * 4 + 10`")
        with col2:
            st.info("📝 **Word Counter**\nCounts words in text")
        with col3:
            st.info("📋 **Text Summary**\nSummarises text info")

        st.markdown("**Try an example task:**")
        examples = [
            "What is 15% of 85000 plus 3200?",
            "Count the words in: 'Artificial intelligence is transforming the world rapidly and efficiently.'",
            "What is 2 raised to the power 10?",
        ]
        for ex in examples:
            if st.button(f"▶ {ex}", key=ex):
                st.session_state["agent_task"] = ex

        task = st.text_input(
            "Or type your own task:",
            value=st.session_state.get("agent_task", ""),
            placeholder="e.g. What is 144 divided by 12?"
        )

        if st.button("🚀 Run Agent", type="primary") and task:
            with st.spinner("Agent thinking and using tools..."):
                result = run_agent(task, model)
            st.success("**Agent response:**")
            st.markdown(result)

            st.caption("The agent autonomously decided which tool to use — this is the core of LangChain agentic AI.")

    # ── Section 3: HuggingFace GPT-2 ──────────────────────────────────────────
    elif section == "🤗 Local GPT-2 (HuggingFace)":
        st.subheader("🤗 HuggingFace Transformers — GPT-2 Running Locally")
        st.caption("No API key needed · Downloads once · Runs on CPU · ~500MB")

        st.markdown("""
        **How HuggingFace Transformers works:**
        1. `from transformers import pipeline` — loads the library
        2. `pipeline('text-generation', model='gpt2')` — downloads GPT-2 weights
        3. Model runs entirely on your machine — no cloud, no cost
        4. The same API works for BLOOM, Falcon, LLaMA (with more RAM/GPU)

        **Other popular HuggingFace models:**
        | Model | Org | Params | Use |
        |---|---|---|---|
        | GPT-2 | OpenAI | 117M | Text generation |
        | BLOOM | BigScience | 176B | Multilingual generation |
        | Falcon | TII | 7B–40B | Open-source foundation |
        | LLaMA 2 | Meta | 7B–70B | Open alternative to proprietary |
        | Mistral | Mistral AI | 7B | Efficient open-source LLM |
        """)

        st.divider()
        prompt = st.text_area(
            "Enter a text prompt for GPT-2:",
            value="Artificial intelligence is changing the world by",
            height=80,
        )

        if st.button("🤗 Generate with GPT-2", type="primary"):
            if not HF_AVAILABLE:
                st.error("Install transformers: `pip install transformers torch`")
            else:
                with st.spinner("Loading GPT-2 locally and generating..."):
                    output = generate_with_gpt2(prompt)
                st.success("**GPT-2 generated text:**")
                st.markdown(f"> {output}")
                st.caption("This ran 100% locally on your machine using the HuggingFace transformers library.")


if __name__ == "__main__":
    main()
