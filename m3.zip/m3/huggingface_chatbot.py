"""
Hugging Face Chatbot (Open-Source Model)
---------------------------------------
Runs on VS Code or Google Colab.
No API key required.
"""

from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
import torch


def main():
    model_name = "microsoft/phi-2"

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        device_map="auto"
    )

    chatbot = pipeline(
        "text-generation",
        model=model,
        tokenizer=tokenizer,
        max_new_tokens=200,
        temperature=0.3
    )

    print("Hugging Face Chatbot started (type 'exit' to quit)")

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Chatbot: Goodbye 👋")
            break

        prompt = f"User: {user_input}\nAssistant:"
        response = chatbot(prompt)
        reply = response[0]["generated_text"].split("Assistant:")[-1]
        print("Chatbot:", reply)


if __name__ == "__main__":
    main()
