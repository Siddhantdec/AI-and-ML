from langchain_groq import ChatGroq
from dotenv import load_dotenv
import streamlit as st

load_dotenv()

# Using LLaMA 3.1 via Groq
model = ChatGroq(model="llama-3.1-8b-instant")

st.header('Research Tool')

user_input = st.text_input("Enter your prompt")

if st.button('Submit'):
    if user_input.strip():
        with st.spinner("Thinking..."):
            result = model.invoke(user_input)
        st.write(result.content)
    else:
        st.warning("Please enter a prompt before submitting.")
