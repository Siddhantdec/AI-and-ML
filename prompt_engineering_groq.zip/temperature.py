from langchain_groq import ChatGroq
from dotenv import load_dotenv

load_dotenv()

# Groq supports temperature between 0 and 2
# Higher temperature = more creative/random output
model = ChatGroq(model="llama-3.3-70b-versatile", temperature=1.5)

result = model.invoke("Write a 5 line poem on cricket")

print(result.content)
