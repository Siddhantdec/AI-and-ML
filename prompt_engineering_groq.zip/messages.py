from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_groq import ChatGroq
from dotenv import load_dotenv

load_dotenv()

# Using LLaMA 3.1 via Groq
model = ChatGroq(model="llama-3.1-8b-instant")

messages = [
    SystemMessage(content='You are a helpful assistant'),
    HumanMessage(content='Tell me about LangChain')
]

result = model.invoke(messages)

# Append AI response to message history
messages.append(AIMessage(content=result.content))

print("Response:\n", result.content)
print("\nFull Message History:")
print(messages)
