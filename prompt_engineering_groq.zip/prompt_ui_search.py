import os

# Print the resolved file path of prompt_ui.py (useful for debugging path issues)
file_path = os.path.join(os.path.dirname(__file__), "prompt_ui.py")
print("File Path:", file_path)

# Also print the current working directory for reference
print("Current Working Directory:", os.getcwd())
