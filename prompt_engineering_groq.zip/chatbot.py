from langchain_groq import ChatGroq
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from dotenv import load_dotenv

load_dotenv()

# Using LLaMA 3.1 via Groq (fast & free)
model = ChatGroq(model="llama-3.1-8b-instant")

chat_history = [
    SystemMessage(content='You are a helpful AI assistant')
]

print("Chatbot is ready! Type 'exit' to quit.\n")

while True:
    user_input = input('You: ')
    if user_input.strip().lower() == 'exit':
        print("Goodbye!")
        break
    chat_history.append(HumanMessage(content=user_input))
    result = model.invoke(chat_history)
    chat_history.append(AIMessage(content=result.content))
    print("AI:", result.content)

print("\nChat History:")
print(chat_history)
