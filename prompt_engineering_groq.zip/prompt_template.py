from langchain_core.prompts import PromptTemplate
from langchain_groq import ChatGroq
from dotenv import load_dotenv

load_dotenv()

# Using LLaMA 3.1 via Groq
model = ChatGroq(model="llama-3.1-8b-instant")

# Define the prompt template
template = PromptTemplate(
    template='Greet this person in 5 languages. The name of the person is {name}',
    input_variables=['name']
)

# Fill in the placeholder values
prompt = template.invoke({'name': 'Nitish'})

# Invoke the model
result = model.invoke(prompt)

print(result.content)
