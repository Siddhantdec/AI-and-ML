from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage
from langchain_groq import ChatGroq
from dotenv import load_dotenv

load_dotenv()

model = ChatGroq(model="llama-3.1-8b-instant")

# Chat template with MessagesPlaceholder for chat history
chat_template = ChatPromptTemplate([
    ('system', 'You are a helpful customer support agent'),
    MessagesPlaceholder(variable_name='chat_history'),
    ('human', '{query}')
])

# Load chat history from file if it exists
chat_history = []
try:
    with open('new_chat_history.txt', 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip().rstrip(',')
            if line.startswith('HumanMessage'):
                content = line.split('"')[1]
                chat_history.append(HumanMessage(content=content))
            elif line.startswith('AIMessage'):
                content = line.split('"')[1]
                chat_history.append(AIMessage(content=content))
except FileNotFoundError:
    print("No previous chat history found. Starting with an empty history.")

print("Loaded chat history:", chat_history)

# Create prompt with history and new query
prompt = chat_template.invoke({
    'chat_history': chat_history,
    'query': 'Where is my refund?'
})

print("\nPrompt:\n", prompt)

# Get response from model
result = model.invoke(prompt)
print("\nAgent Response:\n", result.content)
