from langchain_groq import ChatGroq
from dotenv import load_dotenv
import streamlit as st
from langchain_core.prompts import load_prompt
import warnings
import os

warnings.filterwarnings("ignore", message=".*missing ScriptRunContext.*")

load_dotenv()

# Using LLaMA 3.3 70B via Groq for better research summaries
model = ChatGroq(model="llama-3.3-70b-versatile")

st.header('Research Tool')

paper_input = st.selectbox(
    "Select Research Paper Name",
    [
        "Attention Is All You Need",
        "BERT: Pre-training of Deep Bidirectional Transformers",
        "GPT-3: Language Models are Few-Shot Learners",
        "Diffusion Models Beat GANs on Image Synthesis"
    ]
)

style_input = st.selectbox(
    "Select Explanation Style",
    ["Beginner-Friendly", "Technical", "Code-Oriented", "Mathematical"]
)

length_input = st.selectbox(
    "Select Explanation Length",
    ["Short (1-2 paragraphs)", "Medium (3-5 paragraphs)", "Long (detailed explanation)"]
)

# Load saved template — template.json must be in the same folder as this script
template_path = os.path.join(os.path.dirname(__file__), 'template.json')
template = load_prompt(template_path)

if st.button('Summarize'):
    with st.spinner("Generating summary..."):
        chain = template | model
        result = chain.invoke({
            'paper_input': paper_input,
            'style_input': style_input,
            'length_input': length_input
        })
    st.write(result.content)
