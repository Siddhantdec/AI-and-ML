# Contoso HR Policy — RAG Q&A System

A fully working, **open-source, no-API-key** Retrieval-Augmented Generation (RAG)
system that answers questions about the Contoso HR Policy Manual using:

| Component | Library / Model |
|-----------|-----------------|
| **Embeddings** | `sentence-transformers/all-MiniLM-L6-v2` (~80 MB) |
| **Vector Store** | FAISS (flat inner-product index, cosine similarity) |
| **LLM** | `google/flan-t5-base` (~250 MB, CPU-friendly) |
| **PDF Reading** | pypdf |

Everything runs **100% locally** — no OpenAI, no Anthropic, no API costs.

---

## Quick Start

```bash
# 1. Install dependencies (one-time, ~400 MB download)
pip install -r requirements.txt

# 2. Run interactive Q&A (uses embedded policy text if PDF not found)
python contoso_hr_rag.py

# 3. Or pass your PDF explicitly
python contoso_hr_rag.py --pdf Contoso_HR_Policy.pdf

# 4. Ask a single question
python contoso_hr_rag.py --question "How many sick days do I get per year?"

# 5. Run all 10 demo questions automatically
python contoso_hr_rag.py --demo
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        RAG PIPELINE                             │
│                                                                 │
│  PDF / Text                                                     │
│      │                                                          │
│      ▼                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  CHUNKER  (sliding window, 512 chars, 80 overlap)        │  │
│  └──────────────────────────────────────────────────────────┘  │
│      │  N chunks                                               │
│      ▼                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  EMBEDDER  (all-MiniLM-L6-v2 → 384-dim float32)         │  │
│  └──────────────────────────────────────────────────────────┘  │
│      │  embeddings matrix  [N × 384]                           │
│      ▼                                                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  FAISS IndexFlatIP  (cosine similarity, L2-normalised)   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  At query time:                                                 │
│                                                                 │
│  Question ──► Embedder ──► FAISS.search(top_k=4)               │
│                                  │                              │
│                               top-4 chunks                      │
│                                  │                              │
│                                  ▼                              │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  PROMPT BUILDER                                          │  │
│  │  "Answer using only the context below…                   │  │
│  │   Context: [chunk1] [chunk2] [chunk3] [chunk4]           │  │
│  │   Question: {question}                                   │  │
│  │   Answer:"                                               │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                  │                              │
│                                  ▼                              │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  LLM  (flan-t5-base text2text-generation pipeline)       │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                  │                              │
│                               Answer + Sources                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Sample Output

```
❓ Question:
   How many days of annual leave do I get after 5 years of service?

💡 Answer:
   30 days

📚 Sources (top 4 chunks):
   [1] chunk=08  score=0.872
       3.1 Annual Leave Full-time employees accrue 25 days of paid annual leave…
   [2] chunk=09  score=0.741
       Service Length Annual Leave Entitlement 0–2 years: 25 days  2–5 years: 27 days…
```

---

## Swapping the LLM

Change the `LLM_MODEL_ID` constant at the top of the file, or use `--model`:

| Model | Size | Quality | Hardware |
|-------|------|---------|----------|
| `google/flan-t5-base` *(default)* | ~250 MB | Good for factual Q&A | Any CPU |
| `google/flan-t5-large` | ~800 MB | Better phrasing | CPU (slow) / GPU |
| `google/flan-t5-xl` | ~3 GB | Great quality | GPU recommended |
| `microsoft/phi-2` | ~5 GB | Excellent | GPU (8 GB VRAM) |
| `HuggingFaceH4/zephyr-7b-beta` | ~14 GB | Best | GPU (16 GB VRAM) |

```bash
python contoso_hr_rag.py --model google/flan-t5-large
```

For `phi-2` or `zephyr-7b`, switch the pipeline type to `"text-generation"` in
`load_llm()` and adjust the prompt format accordingly.

---

## Using with LangChain (optional)

The code is intentionally written **without LangChain** to keep dependencies minimal
and make each step crystal clear. If you prefer the LangChain API, the equivalent is:

```python
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.llms import HuggingFacePipeline
from langchain.chains import RetrievalQA

embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
db = FAISS.from_texts([c["text"] for c in chunks], embeddings)
retriever = db.as_retriever(search_kwargs={"k": 4})

llm = HuggingFacePipeline.from_model_id(
    model_id="google/flan-t5-base",
    task="text2text-generation",
    pipeline_kwargs={"max_new_tokens": 256},
)

chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
print(chain.run("How many sick days do I get?"))
```

---

## File Structure

```
contoso_hr_rag.py   ← Main application (self-contained)
requirements.txt    ← Python dependencies
README.md           ← This file
Contoso_HR_Policy.pdf  ← Place the PDF here (optional — embedded fallback included)
```

---

## Notes

- **PDF optional**: The full HR policy text is embedded in the Python file as a
  fallback constant, so the app works even without the PDF on disk.
- **No internet at inference**: After the one-time model download, everything runs offline.
- **Deterministic answers**: `do_sample=False` is set for reproducible answers.
  Set `do_sample=True` with a temperature for more varied responses.
- **Extending to other documents**: Change the PDF path or swap `EMBEDDED_HR_POLICY`
  with your own text to use any document.
