#import os
#print("Current Working Directory:", os.getcwd())





import os
file_path = os.path.join(os.path.dirname(__file__), "prompt_ui.py")
print("File Path:", file_path)
