from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage
# chat template
chat_template = ChatPromptTemplate([
    ('system','You are a helpful customer support agent'),
    MessagesPlaceholder(variable_name='chat_history'),
    ('human','{query}')
])

chat_history = []
# Try to load chat history from file if it exists
try:
    with open('new_chat_history.txt', 'r') as f:
        chat_history.extend([line.strip() for line in f.readlines()])
except FileNotFoundError:
    print("No previous chat history found. Starting with an empty history.")

print(chat_history)

# create prompt
prompt = chat_template.invoke({'chat_history':chat_history, 'query':'Where is my refund'})

print(prompt)